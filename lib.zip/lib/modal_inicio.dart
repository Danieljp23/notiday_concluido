import 'package:flutter/material.dart';
import 'package:notiday_1/Objetos/Compromissos.dart';
import 'package:notiday_1/components/decoracao.dart';
import 'package:notiday_1/conection/firestore_servi%C3%A7o.dart';

import 'package:uuid/uuid.dart';

mostrarModalInicio(BuildContext context) {
  showModalBottomSheet(
      context: context,
      isDismissible: false,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(32),
        ),
      ),
      builder: (context) {
        return const ExercicioModal();
      });
}

class ExercicioModal extends StatefulWidget {
  const ExercicioModal({super.key});

  @override
  State<ExercicioModal> createState() => _ExercicioModalState();
}

class _ExercicioModalState extends State<ExercicioModal> {
  TextEditingController nameCTR = TextEditingController();
  TextEditingController horarioCTR = TextEditingController();
  TextEditingController descricaoCTR = TextEditingController();
  TextEditingController dataCTR = TextEditingController();
  TextEditingController enderecoCTR = TextEditingController();


  bool isCarregando = false;

  CompromissoServico _compromissoServico = CompromissoServico();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Colors.blue,
      borderRadius: BorderRadius.circular(16),),
      padding: EdgeInsets.all(32),
      height: MediaQuery.of(context).size.height * 0.9,
      child: Form(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "Adicionar exercicio",
                      style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                    IconButton(
                      onPressed: () {
                        Navigator.of(context);
                      },
                      icon: const Icon(
                        Icons.close,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                const Divider(),
                Column(
                  children: [
                    const SizedBox(
                      height: 16,
                    ),
                    TextFormField(
                      controller: nameCTR,
                      decoration: getDecorationInput(
                        "Qual nome do compromisso?",
                        icon: const Icon(
                          Icons.abc,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    TextFormField(
                      controller: horarioCTR,
                      decoration: getDecorationInput(
                        "Hora:",
                        icon: const Icon(
                          Icons.list_alt_rounded,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    TextFormField(
                      controller: descricaoCTR,
                      decoration: getDecorationInput(
                        "Descrição",
                        icon: const Icon(
                          Icons.notes_rounded,
                          color: Colors.white,
                        ),
                      ),
                      maxLines: null,
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    TextFormField(
                      controller: dataCTR,
                      decoration: getDecorationInput(
                        "Data do compromisso:",
                        icon: const Icon(
                          Icons.emoji_emotions_rounded,
                          color: Colors.white,
                        ),
                      ),
                      maxLines: null,
                    ),
                    TextFormField(
                      controller: enderecoCTR,
                      decoration: getDecorationInput(
                        "Endereco:",
                        icon: const Icon(
                          Icons.emoji_emotions_rounded,
                          color: Colors.white,
                        ),
                      ),
                      maxLines: null,
                    ),
                    
                  ],
                ),
              ],
            ),
            //elevated button que executa a função de envio de treino
            ElevatedButton(
              onPressed: () {
                enviarClicado();
              },
              child: (isCarregando)
                  ? const SizedBox(
                      height: 16,
                      width: 16,
                      child: CircularProgressIndicator(color: Colors.amber,),
                    )
                  : const Text("Criar Exercício",),
            ),
          ],
        ),
      ),
    );
  }

//função que adiciona no CloundFirestore meu treino com base no userId gerado na instancia do FirebaseAuth, e cria seus respectivos atributos
    
      
    enviarClicado() {
  String name = nameCTR.text;
    String horario = horarioCTR.text;
    String descricao = descricaoCTR.text;
    String data = dataCTR.text;
    String endereco = enderecoCTR.text;
   
//intancia da classe ExercicioModelo, que cria o objeto ExercicioModelo
    Compromisso compromisso = Compromisso(
     id: const Uuid().v1(),
      name: name,
      horario: horario,
      descricao: descricao,
      data: data,
      endereco: endereco,
     
    );
    _compromissoServico.adicionarCompromisso(compromisso).then((value) {
      
     
            
          setState(() {
            isCarregando = false;
          });
          Navigator.pop(context);
        });
     
    
  }
}
