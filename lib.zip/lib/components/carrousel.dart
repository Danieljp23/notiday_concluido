import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import "package:url_launcher/url_launcher.dart"; // Importação necessária para abrir URLs

class Maps extends StatefulWidget {
  @override
  _MapsState createState() => _MapsState();
}

class _MapsState extends State<Maps> {
  int _currentIndex = 0;

  List<String> imagePaths = [
    'assets/uber.png',
    'assets/99.png',
    'assets/maps.png',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
         
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              
              CarouselSlider.builder(
                itemCount: imagePaths.length,
                itemBuilder: (BuildContext context, int index, int realIndex) {
                  return GestureDetector(
                    onTap: () {
                      _openWebsite(index);
                    },
                    child: buildImage(imagePaths[index]),
                  );
                },
                options: CarouselOptions(
                  height: 120,
                  autoPlay: true,
                  pageSnapping: false,
                  enableInfiniteScroll: true,
                  enlargeStrategy: CenterPageEnlargeStrategy.height,
                  enlargeCenterPage: true,
                  autoPlayInterval: const Duration(seconds: 4),
                  onPageChanged: (index, reason) {
                    setState(() {
                      _currentIndex = index;
                    });
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
//container da imagem do carroussel
  Widget buildImage(String imagePath) => Container(

 
    child:AspectRatio(
      aspectRatio:10,
    child: Image.asset(
      imagePath,
      fit: BoxFit.cover,
      
    ),
  ),
  );
  void _openWebsite(int index) {
    String websiteUrl;
    // Determinar o site correspondente ao índice da imagem
    switch (index) {
      case 0:
        websiteUrl = 'https://www.uber.com/br/';
        break;
      case 1:
        websiteUrl = 'https://www.99app.com/';
        break;
      case 2:
        websiteUrl = 'https://www.google.com.br/maps/@-21.7874432,-48.1492992,14z?entry=ttu';
        break;
      default:
        websiteUrl = 'https://www.example.com'; // Página padrão
    }
    // Abrir o site no navegador
    launch(websiteUrl);
  }
}