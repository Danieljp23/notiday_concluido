
import  "package:flutter/material.dart";

mostrarSnackBar({
required BuildContext context,
required String texto,
bool isErro = false
}){
  SnackBar snackBar = SnackBar(content: Text(texto),
  backgroundColor: isErro ? Colors.red : Colors.green,
  shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top:Radius.circular(20),),),
  duration: const Duration(seconds: 4),);
 
  ScaffoldMessenger.of(context).showSnackBar(snackBar);
  Future.delayed(const Duration(seconds: 4), () {
   
    Navigator.pop(context);
  });
}
mostrarSnackBarLogin({
required BuildContext context,
required String texto,
bool isErro = false
}){
  SnackBar snackBar = SnackBar(content: Text(texto),
  backgroundColor: (!isErro) ? Colors.red : Colors.green,
  shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top:Radius.circular(20),),),
  duration: const Duration(seconds: 4),);
 
  ScaffoldMessenger.of(context).showSnackBar(snackBar);
  
}