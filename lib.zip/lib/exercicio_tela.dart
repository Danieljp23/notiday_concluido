import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:notiday_1/Objetos/Compromissos.dart';
import 'package:notiday_1/inicio.dart';
import 'package:notiday_1/main.dart';
import 'package:notiday_1/login.dart';

String colecao = '';

class CompromissoTela extends StatefulWidget {
  final Compromisso compromisso;
  CompromissoTela({Key? key, required this.compromisso}) : super(key: key);

  @override
  _CompromissoTelaState createState() => _CompromissoTelaState();
}

class _CompromissoTelaState extends State<CompromissoTela> {
  TextEditingController _idController = TextEditingController();
  TextEditingController _nameController = TextEditingController();
  TextEditingController _horarioController = TextEditingController();
  TextEditingController _descricaoController = TextEditingController();
  TextEditingController _enderecoController = TextEditingController();
  TextEditingController _dataController = TextEditingController();
  TextEditingController _tintaController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _idController.text = widget.compromisso.id;
    _nameController.text = widget.compromisso.name;
    _horarioController.text = widget.compromisso.horario;
    _descricaoController.text = widget.compromisso.descricao;
    _enderecoController.text = widget.compromisso.endereco;
    _dataController.text = widget.compromisso.data;
  }

  @override
  Widget build(BuildContext context) {
  return Scaffold(
    backgroundColor: Colors.blue,
    appBar: AppBar(
      title: Container(
        padding: EdgeInsets.all(90),
        child: TextField(
          controller: _nameController,
          readOnly: true, // Define o TextField como somente leitura
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
          decoration: InputDecoration(
            border: InputBorder.none,
          ),
        ),
      ),
      centerTitle: true,
      elevation: 0,
      toolbarHeight: 72,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          bottom: Radius.circular(32),
        ),
      ),
    ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          FloatingActionButton(
            onPressed: () {
              // Salvar as alterações
              _salvarAlteracoes(context);
            },
            child: Icon(Icons.save),
          ),
          SizedBox(height: 16),
          FloatingActionButton(
            onPressed: () {
              // Excluir o compromisso
              _excluirCompromisso(context);
            },
            child: Icon(Icons.delete),
            backgroundColor: Colors.red,
          ),
        ],
      ),
      body: Container(
        margin: const EdgeInsets.all(8),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: ListView(
          children: [
            const Text(
              "Assunto:",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            TextField(
              controller: _nameController,
              maxLines: null,
              decoration: InputDecoration(
                border: InputBorder.none,
              ),
            ),
            const Text(
              "Descrição:",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            TextField(
              controller: _descricaoController,
              maxLines: null,
              decoration: InputDecoration(
                border: InputBorder.none,
              ),
            ),
            const SizedBox(
              height: 25,
            ),
            const Text(
              "Data:",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            TextField(
              controller: _horarioController,
              maxLines: null,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                border: InputBorder.none,
              ),
            ),
            const SizedBox(
              height: 25,
            ),
            const Text(
              "Endereço:",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            TextField(
              controller: _enderecoController,
              maxLines: null,
              decoration: InputDecoration(
                border: InputBorder.none,
              ),
            ),
            const Text(
              "Horario:",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            TextField(
              controller: _horarioController,
              maxLines: null,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                border: InputBorder.none,
              ),
            ),
            const SizedBox(
              height: 25,
            ),
            const Text(
              "como estou me sentindo!",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            const SizedBox(
              height: 8,
            ),
          ],
        ),
      ),
    );
  }

  void _salvarAlteracoes(BuildContext context) async {
    try {
      // Obtém uma referência para a coleção 'compromissos' no Firestore
      CollectionReference compromissos = FirebaseFirestore.instance
          .collection(FirebaseAuth.instance.currentUser!.uid);

      // Salva os dados do compromisso no Firestore
      await compromissos.doc(widget.compromisso.id).update({
        'name': _nameController.text,
        'horario': _horarioController.text,
        'descricao': _descricaoController.text,
        'endereco': _enderecoController.text,
        'id': _idController.text,
      }).then((_) {
        // Exibe uma mensagem de sucesso
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Alterações salvas com sucesso!'),
        ));
        // Retorna para a página inicial
        Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => MyApp(),
        ));
      }).catchError((error) {
        // Exibe uma mensagem de erro se houver algum problema ao salvar os dados
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Erro ao salvar as alterações: $error'),
          backgroundColor: Colors.red,
        ));
      });
    } catch (e) {
      // Exibe uma mensagem de erro se houver algum problema ao salvar os dados
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Erro ao salvar as alterações: $e'),
        backgroundColor: Colors.red,
      ));
    }
  }

  void _excluirCompromisso(BuildContext context) async {
    try {
      // Obtém uma referência para a coleção 'compromissos' no Firestore
      CollectionReference compromissos = FirebaseFirestore.instance
          .collection(FirebaseAuth.instance.currentUser!.uid);

      // Exclui o compromisso do Firestore
      await compromissos.doc(widget.compromisso.id).delete().then((_) {
        // Exibe uma mensagem de sucesso
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Compromisso excluído com sucesso!'),
          backgroundColor: Colors.green,
        ));
        Navigator.of(context).pop();
      }).catchError((error) {
        // Exibe uma mensagem de erro se houver algum problema ao excluir o compromisso
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Erro ao excluir o compromisso: $error'),
          backgroundColor: Colors.red,
        ));
      });
    } catch (e) {
      // Exibe uma mensagem de erro se houver algum problema ao excluir o compromisso
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Erro ao excluir o compromisso: $e'),
        backgroundColor: Colors.red,
      ));
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _horarioController.dispose();
    _descricaoController.dispose();
    _enderecoController.dispose();
    super.dispose();
  }
}

Future<String> getCollectionsForCurrentUser() async {
  // Verifique se há um usuário autenticado
  String colecao = '';
  User? user = FirebaseAuth.instance.currentUser;

  if (user != null) {
    // Acesse o Firestore e consulte as coleções do usuário atual
    QuerySnapshot userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('collections')
        .get();

    // Itere sobre os documentos retornados e imprima o nome das coleções
    userDoc.docs.forEach((doc) {
      colecao = doc.id;
    });
  }

  print('oiee $colecao');
  return colecao;
}
