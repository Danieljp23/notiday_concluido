import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:notiday_1/Objetos/Compromissos.dart';
import 'package:notiday_1/components/carrousel.dart';
import 'package:notiday_1/conection/criausuario.dart';
import 'package:notiday_1/conection/firestore_serviço.dart';
import 'package:notiday_1/exercicio_tela.dart';
import 'package:notiday_1/main.dart';
import 'package:notiday_1/modal_inicio.dart';
import 'package:notiday_1/ajuda.dart';
import 'package:notiday_1/configuracoes.dart';
import 'package:notiday_1/recuperasenha.dart';
import 'package:notiday_1/registrar.dart'; // Corrigido o nome do arquivo
import 'package:firebase_auth/firebase_auth.dart';
import 'package:notiday_1/exercicio_tela.dart';

class Inicio extends StatefulWidget {
  final User user;
  const Inicio({Key? key, required this.user}) : super(key: key);

  @override
  State<Inicio> createState() => _InicioState();
}

class _InicioState extends State<Inicio> {
  final CompromissoServico servico = CompromissoServico();
  final AutenticaUser deslogar = AutenticaUser();

  List<String> avatars = [
    'assets/avatar/avatar1.jpg',
    'assets/avatar/avatar2.jpg',
    'assets/avatar/avatar3.jpg',
    'assets/avatar/avatar4.jpg',
  ];

  Future<int?> obterIndexFoto() async {
    try {
      String userId = FirebaseAuth.instance.currentUser!.uid;

      DocumentSnapshot snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .get();
if (snapshot.exists && snapshot.data() != null && snapshot.data()!['selectedFotoIndex'] != null) {
    return snapshot.data()?.['selectedFotoIndex'];

} else {
  return null;
}

    } catch (error) {
      print('Erro ao obter o indexfoto do Firestore: $error');
      return null;
    }
  }

  void carregarAvatar() async {
    try {
      int? selectedFotoIndex = await obterIndexFoto();
      if (selectedFotoIndex != null) {
        print('Index da foto do usuário: $selectedFotoIndex');
      } else {
        print('O campo indexfoto não está disponível.');
      }
    } catch (error) {
      print('Erro ao carregar a foto de perfil do usuário: $error');
    }
  }

  @override
  void initState() {
    super.initState();
    carregarAvatar();
  }

  String fotoPerfil = "";
  int? selectedFotoIndex;
  String fotoSelecionada = '';

  void salvarFotoSelecionada(
      int? selectedFotoIndex, String? fotoSelecionada) async {
    try {
      String userId = FirebaseAuth.instance.currentUser!.uid;

      QuerySnapshot compromissos = await FirebaseFirestore.instance
          .collection(userId)
          .limit(1)
          .get();

      if (compromissos.docs.isNotEmpty) {
        String documentoId = compromissos.docs.first.id;

        DocumentReference compromissoRef = FirebaseFirestore.instance
            .collection(userId)
            .doc(documentoId);

        compromissoRef.update({
          'selectedFotoIndex': selectedFotoIndex,
          'fotoSelecionada': fotoSelecionada,
        }).then((_) {
          setState(() {
            fotoPerfil = fotoSelecionada!;
            this.selectedFotoIndex = selectedFotoIndex;
          });
          print(
              'Índice e URL da foto selecionada atualizados com sucesso no banco de dados! $fotoPerfil');
        }).catchError((error) {
          print('Erro ao atualizar o índice e a URL da foto selecionada: $error');
        });
      } else {
        print('Nenhum documento encontrado para atualizar.');
      }
    } catch (error) {
      print('Erro ao salvar a foto selecionada: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(kToolbarHeight),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.only(
              bottomRight: Radius.circular(20),
              bottomLeft: Radius.circular(20),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                spreadRadius: 1,
                blurRadius: 10,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: AppBar(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(
                bottom: Radius.circular(20),
              ),
            ),
            title: Container(
              child: Row(
                children: [
                  SizedBox(width: 120.0),
                  Text(
                    'Notiday',
                    style: TextStyle(
                      fontSize: 30,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      endDrawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Opções',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                    ),
                  ),
                  SizedBox(height: 10),
                  GestureDetector(
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text('Selecione uma Foto'),
                            content: Container(
                              width: double.maxFinite,
                              child: GridView.count(
                                crossAxisCount: 2,
                                mainAxisSpacing: 10.0,
                                crossAxisSpacing: 10.0,
                                shrinkWrap: true,
                                children: avatars.map((avatarsPath) {
                                  return GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        selectedFotoIndex =
                                            avatars.indexOf(avatarsPath);
                                        fotoSelecionada = avatarsPath;
                                        salvarFotoSelecionada(
                                            selectedFotoIndex, fotoSelecionada);
                                      });
                                      Navigator.of(context).pop();
                                    },
                                    child: CircleAvatar(
                                      backgroundImage: AssetImage(avatarsPath),
                                      radius: 40.0,
                                    ),
                                  );
                                }).toList(),
                              ),
                            ),
                          );
                        },
                      );
                    },
                    child: CircleAvatar(
                      backgroundImage: AssetImage(fotoPerfil),
                      radius: 40.0,
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              title: Text('Configurações'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Configuracoes(),
                  ),
                );
              },
            ),
            ListTile(
              title: Text('Ajuda'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AJuda(),
                  ),
                );
              },
            ),
            ListTile(
              title: Text('Sair do App'),
              onTap: () async {
                Navigator.pop(context);
                try {
                  await FirebaseAuth.instance.signOut();
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => MyApp()),
                    (route) => false,
                  );
                } catch (e) {
                  print("Erro ao deslogar: $e");
                }
              },
            ),
          ],
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/bg_recuperasenha.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: StreamBuilder(
          stream: servico.conectarStreamCompromisso(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(
                child: CircularProgressIndicator(),
              );
            } else {
              if (snapshot.hasData &&
                  snapshot.data != null &&
                  snapshot.data!.docs.isNotEmpty) {
                List<Compromisso> listacompromisso = [];
                for (var doc in snapshot.data!.docs) {
                  listacompromisso.add(
                    Compromisso.fromMap(
                      doc.data(),
                    ),
                  );
                }
                return Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: 300,
                      child: ListView.separated(
                        itemCount: listacompromisso.length,
                        separatorBuilder: (context, index) => Divider(),
                        itemBuilder: (context, index) {
                          Compromisso compromisso = listacompromisso[index];
                          return ListTile(
                            title: Text(compromisso.name),
                            subtitle: Text(compromisso.horario),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => CompromissoTela(
                                    compromisso: compromisso,
                                  ),
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ),
                    SizedBox(
                      height: 86,
                    ),
                    Container(
                      margin: EdgeInsets.all(2),
                      height: 120,
                      width: 400,
                      child: Maps(),
                    ),
                  ],
                );
              } else {
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      height: 200,
                      width: 200,
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage('assets/Não.png'),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ],
                );
              }
            }
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          mostrarModalInicio(context);
        },
        backgroundColor: Color.fromARGB(255, 243, 166, 0),
        foregroundColor: Colors.black,
        child: Icon(Icons.add),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}
