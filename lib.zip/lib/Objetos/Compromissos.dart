

class Compromisso {
  String id;
  String name;
  String horario;
  String data;
  String descricao;
  String endereco;
  String? fotoSelecionada;
  int? selectedFotoIndex;

  Compromisso({
    required this.id,
    required this.name,
    required this.horario,
    required this.data,
    required this.descricao,
    required this.endereco,
    this.fotoSelecionada, 
    this.selectedFotoIndex,// Agora é opcional
  });

  Compromisso.fromMap(Map<String, dynamic> map)
      : id = map["id"],
        name = map["name"],
        horario = map["horario"],
        data = map["data"],
        descricao = map["descricao"],
        endereco = map["endereco"],
        fotoSelecionada = map["fotoSelecionada"],
        selectedFotoIndex = map["selectedFotoIndex"];

  Map<String, dynamic> toMap() {
    return {
      "id": id,
      "name": name,
      "horario": horario,
      "data": data,
      "descricao": descricao,
      "endereco": endereco,
     if (fotoSelecionada != null) "fotoSelecionada": fotoSelecionada,
      if(selectedFotoIndex != null) "selectedFotoIndex": selectedFotoIndex,
    };
  }
}
